# GitHub and GitLab mirror workflow

Eternal Thread uses more than one Git forge to improve availability and provenance.
A mirror is not evidence of identity merely because its name looks similar: every
release must record the specific source commit, tag, asset name, and checksum.

## Current beta-preparation observation

The connected repositories were checked read-only on 2026-09-01. At that time:

| Host | Repository | Visibility observed | Default-branch head observed |
| --- | --- | --- | --- |
| GitHub | `GremlinNavi/sovereign-ai-framework` | public | `194af2f50be0313469416a4e77da1114ad24115c` |
| GitLab | `eternal-thread-group/sovereign-ai-framework` | private | `989b36032c8393a30408e6e11f22a4ec6d385e05` |

Those are different commits. This document therefore does **not** claim the two
default branches are synchronized. Treat the values as a dated observation and
re-check the actual refs before any release or mirror action.

## Release roles

Choose and record the role of each forge for a release before pushing:

- **Canonical public distribution source:** the reviewed commit and public release
  asset people are directed to verify.
- **Archival mirror:** an independently hosted copy of the reviewed source and tag.
- **Working/review branches:** temporary branches that are never confused with a
  release tag or a published asset.

For the current configuration, GitHub is suitable for the public-distribution role
only if the maintainer explicitly decides it is the release origin. The GitLab copy
must not be presented as a public download location while it remains private.

## Conservative mirror procedure

1. Start from a clean, reviewed checkout and identify the exact release commit.
2. Create an annotated signed tag only after the release checklist passes.
3. Record the canonical commit and its tree ID locally:

   ```text
   git rev-parse v0.4.0-beta.1^{commit}
   git rev-parse v0.4.0-beta.1^{tree}
   ```

4. Push the reviewed branch and tag to the intended canonical host through the
   maintainer's approved workflow.
5. Push the same reviewed refs to the mirror without rewriting either host's
   history. Never use `--force` merely to make unrelated branch histories match.
6. Compare each tagged commit's tree ID. If host-specific merge commits make commit
   IDs differ, compare the intended source tree and the final release-asset SHA-256
   values instead of claiming the commits are identical.
7. Download each published asset independently, verify its checksum, and record the
   host-specific URLs in `PROVENANCE.md`.

If a branch cannot fast-forward, stop and investigate the divergence. Preserve the
existing histories, create a documented integration branch if needed, and obtain
maintainer approval before any merge or remote update.

## Optional GitHub CLI integration

The GitHub CLI can reduce transcription mistakes, but it is not required and it must
remain a deliberate release step. Read-only preflight commands include:

```text
gh auth status
gh repo view GremlinNavi/sovereign-ai-framework
gh release view v0.4.0-beta.1 --repo GremlinNavi/sovereign-ai-framework
```

After every release gate has been completed and the maintainer authorizes a remote
write, a human-reviewed `gh release create` command may attach the exact ZIP,
`SHA256SUMS.txt`, and release notes as a pre-release. The command must name the
specific tag and assets; do not automate visibility changes, force pushes, or release
publication from an unreviewed script.

The supplied project scripts do not push or synchronize a remote. See
[GIT_WORKFLOW.md](GIT_WORKFLOW.md) for the guarded named-file push helper and
[RELEASE_AUTHENTICITY.md](RELEASE_AUTHENTICITY.md) for verification requirements.
