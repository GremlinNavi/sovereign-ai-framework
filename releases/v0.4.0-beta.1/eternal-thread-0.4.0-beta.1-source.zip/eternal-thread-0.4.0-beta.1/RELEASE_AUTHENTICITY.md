# Release authenticity and checksum workflow

This document describes how to verify an Eternal Thread release candidate. It does
not claim that this beta package, any Git tag, or any hosted release has already
been cryptographically signed.

## What each check establishes

| Check | Establishes | Does not establish |
| --- | --- | --- |
| SHA-256 checksum | The downloaded file is byte-for-byte identical to the checked release asset. | Who created the asset or whether its contents are safe. |
| Signed Git tag | The tag can be verified with a trusted maintainer signing key. | That the build environment or every dependency was trustworthy. |
| Hosted release URL | Where an asset was obtained. | That a domain or forge account alone proves authorship. |
| Antivirus scan | That a scanner did or did not detect known threats at scan time. | Complete safety or release authenticity. |

Use these layers together. A checksum published only beside a file on an untrusted
page is weak evidence; a verified tag, independent mirror, release notes, and
checksum offer materially stronger provenance.

## Beta-release bundle

For each release, publish or retain together:

- the versioned source ZIP;
- `SHA256SUMS.txt` beside the ZIP;
- `SOURCE_TREE_SHA256SUMS.txt` inside the ZIP;
- release notes and the provenance record;
- an annotated, signed Git tag when the maintainer has configured a signing key;
- the public signing-key fingerprint or trusted-key location, if a tag is signed.

`tools/Export-EternalThreadSource.ps1` creates a source ZIP, an adjacent
`SHA256SUMS.txt`, and an in-archive source-tree manifest without touching Git,
remotes, tags, or hosted releases. It refuses to replace an existing output file.

## Verify a downloaded ZIP

From the folder containing the release ZIP and `SHA256SUMS.txt`:

```powershell
pwsh -File .\tools\Test-EternalThreadRelease.ps1 `
  -ChecksumFile .\SHA256SUMS.txt `
  -ReleaseAsset .\eternal-thread-v0.4.0-beta.1-source.zip
```

The same read-only command works in Windows PowerShell on Windows and PowerShell 7+
on Windows, Linux, or macOS. On systems with GNU core utilities, the equivalent
checksum verification is:

```text
sha256sum -c SHA256SUMS.txt
```

On macOS, calculate the file hash with `shasum -a 256 <filename>` and compare it
carefully with the matching `SHA256SUMS.txt` entry. Do not compare abbreviated
hashes.

After verifying the ZIP, extract it to a new folder and compare any specific source
file with the `SOURCE_TREE_SHA256SUMS.txt` manifest inside the archive when a more
detailed audit is needed.

## Signed tag workflow for a maintainer

Only sign a tag after completing the release checklist from the exact reviewed Git
commit. Configure a protected GPG or SSH signing key in Git according to the
maintainer's established key-management policy, then create and verify an annotated
tag locally:

```text
git tag -s v0.4.0-beta.1 -m "Eternal Thread v0.4.0-beta.1"
git verify-tag v0.4.0-beta.1
```

Before publication, record the tag target with `git rev-list -n 1
v0.4.0-beta.1`, verify the tag with an independently trusted copy of the public key,
and place the exact tag, target commit, asset filenames, and SHA-256 values in
`PROVENANCE.md`. A DCO sign-off is valuable contribution certification, but it is
not a cryptographic signature.

Do not describe a release as signed merely because a Git hosting interface shows an
account-associated commit. State the signing method and key fingerprint, and only
claim verification after it succeeds with the expected trusted key.

## Boundaries

Checksums, signatures, archive manifests, and mirrors improve evidence and make
accidental corruption or substitution easier to detect. They cannot replace source
review, dependency review, secure build practices, access controls, or a deployment-
appropriate security assessment.

See [ANTIVIRUS_VERIFICATION.md](ANTIVIRUS_VERIFICATION.md) for complementary scan
guidance and [PROVENANCE.md](PROVENANCE.md) for the release-record boundary.
