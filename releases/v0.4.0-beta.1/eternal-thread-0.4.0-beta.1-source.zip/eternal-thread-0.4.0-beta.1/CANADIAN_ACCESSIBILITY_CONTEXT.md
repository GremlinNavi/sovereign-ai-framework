# Canadian accessibility and digital-literacy context

## Why this note exists

The `distro/accessibility-first` branch makes the Windows distribution easier to
find, read, and configure without requiring a person to navigate a developer source
tree. This note records the Canadian public-data context for that design choice.

It is not a claim that Eternal Thread is certified accessible, compliant with the
Accessible Canada Act, suitable for every access need, or a substitute for user
testing with people who use assistive technology. It is also not a claim that a
person's disability determines their technical ability. It does not treat disability
as a proxy for digital literacy. Disability and digital skill are different things;
both the design of a system and the availability of support can create or remove
barriers.

## What the Canadian data says

Statistics Canada reported that, in 2022, nearly 8 million Canadians aged 15 and
over had one or more disabilities. Of those people, about 1.4 million (17.1%)
experienced at least one barrier while using the Internet during the preceding
12 months. The reported barriers included online access to government information,
booking, and online banking or shopping. In a separate 2024 measure, 46% of people
with long-term conditions or disabilities reported difficulty using a technological
device, such as a smartphone or laptop, because of their condition.

The same 2022 survey found that 85% of persons with disabilities had used the
Internet personally in the previous year. That should not be read as proof that the
remaining people lack skill: among the roughly 1.2 million who had not used it,
reasons included that it was too difficult to use (34%), health-related limitation
(13%), cost of service or equipment (10%), lack of an Internet-ready device (9%),
and limited or no Internet access (6%). Those factors can overlap and describe
environmental, financial, and support barriers as well as interface difficulty.

There is no single official statistic that labels Canadians as technologically
"literate." Statistics Canada's Internet-use typology is a useful, explicitly
historical benchmark: using 2018 survey data, it found that more than half of
Canadians were proficient or advanced Internet users, while one quarter either did
not use the Internet or used it only in a basic way. It should not be presented as a
current measurement, but it reinforces the practical point that software should not
assume every user is comfortable with source trees, package management, command-line
tools, or multi-step configuration.

## Relevance to this fork

The fork responds to those facts with modest, inspectable design choices rather than
claims about users:

- A shallow package layout and a plainly named `START_HERE.txt` reduce the amount of
  navigation and terminology required before a person can identify the application,
  documentation, optional tools, and licence information.
- The default path does not require PowerShell. The GUI-preference helper is optional,
  visible as a separate file, and supports `-WhatIf` so a person can understand a
  proposed change before it is made.
- Text scale, light/dark/high-contrast themes, and a remembered opening-window size
  give users local visual choices without altering Windows-wide accessibility
  settings or requiring a cloud account.
- The helper writes only a local, non-secret preference file. It does not change
  source code, Git settings, model or runtime choices, `.env`, or a user's global
  PowerShell policy. A person can remove the preferences with `-Reset` and return to
  the application's defaults.
- Plain-text guidance and an intentionally separate runtime/model step make the
  technical boundary visible. They do not eliminate the need for clear installation
  support, but they avoid hiding consequential choices behind a one-click installer.

These measures aim to reduce avoidable complexity for people with varied access
needs and varied experience with technology. They do not replace keyboard-only,
screen-reader, zoom, contrast, localization, and real-user usability testing. Before
describing a release as accessible, maintainers should test the specific release and
state exactly what was tested, with the operating-system and assistive-technology
versions used.

## Sources and data boundaries

All links below are official Statistics Canada sources. The facts above retain the
survey years because the publication dates and collection periods differ. This note
was reviewed on 2026-09-01 and should be updated when newer relevant Canadian data
is released.

- [Barriers to accessibility related to Internet use: Findings from the 2022 Canadian Survey on Disability](https://www150.statcan.gc.ca/n1/pub/89-654-x/89-654-x2025004-eng.htm) — source for the 8 million, 17.1%, Internet-use, and reason-for-non-use findings.
- [Barriers to Accessibility in Canada: Communication and Internet Use, 2022](https://www150.statcan.gc.ca/n1/daily-quotidien/250324/dq250324b-eng.htm) — source for the 2024 technological-device difficulty figure and the Accessible Canada Act context.
- [Internet-use Typology of Canadians: Online Activities and Digital Skills](https://www150.statcan.gc.ca/n1/pub/11f0019m/11f0019m2021008-eng.htm) — 2018-based digital-skills benchmark; it is included with its historical limitation stated above.
- [Canadian Internet Use Survey (2022)](https://www.statcan.gc.ca/en/survey/household/4432) — describes Statistics Canada's continuing measurement of digital skills and barriers to using digital technology.
