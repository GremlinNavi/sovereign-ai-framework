# PowerShell installation and safe updates

The filename is retained for compatibility with earlier Windows documentation. The
PowerShell helpers now support:

- Windows PowerShell 5.1 or PowerShell 7+ on Windows;
- PowerShell 7+ (`pwsh`) on Linux and macOS.

They are optional, inspectable conveniences for a source checkout. They do not
change a PowerShell execution policy, create or overwrite `.env`, install a runtime
or model, select a backend, or automatically use a remote endpoint.

## Requirements

- Python 3.10 or newer. The installer defaults to `python` on Windows and `python3`
  on Linux/macOS; use `-PythonCommand` when your executable has another name.
- Git only if you intend to use the guarded update helper.
- PowerShell 7+ for Linux/macOS. Windows PowerShell 5.1 is supported only on Windows.

## Install the Python package locally

Run from the repository root:

```powershell
.\tools\Install-EternalThread.ps1
```

The installer preflights Python 3.10+, creates `.venv` only when absent, and uses the
platform-correct virtual-environment interpreter:

- Windows: `.venv\Scripts\python.exe`
- Linux/macOS: `.venv/bin/python`

It installs the base package with `pip install .`, then validates `config.py` with
that virtual environment's interpreter. Validation does not start an AI runtime,
download models, or choose another backend.

The shipped configuration defaults to the Ollama adapter, but the base install
intentionally excludes its optional Python client. If you deliberately selected
Ollama, opt in explicitly:

```powershell
.\tools\Install-EternalThread.ps1 -InstallOllamaClient
```

This installs only `.[ollama]` into the project-local virtual environment. It does
not install or start the Ollama runtime and does not download any model.

Preview before making a virtual environment or installing dependencies:

```powershell
.\tools\Install-EternalThread.ps1 -WhatIf
```

The virtual-environment path must stay inside the checkout and cannot pass through
an existing symbolic link or junction. That prevents a common path escape; it is not
a substitute for trusting the source checkout or controlling the host operating
system.

## Deliberate backend health check

After you have selected and started the intended backend, request a health check:

```powershell
.\tools\Install-EternalThread.ps1 -HealthCheck
```

The check contacts only the configured chat and embedding endpoints and verifies
their selected model names. It does not pick a replacement backend. A non-loopback
endpoint requires `ETERNAL_THREAD_ALLOW_REMOTE_BACKENDS=1` and in-application
consent; see `REMOTE_LOCAL_INFERENCE.md` before using an inference host on a LAN.

## Safely update a clean checkout

`Update-EternalThread.ps1` works from any supported PowerShell host with Git
available. It requires a clean worktree and accepts only an `origin` remote that
matches one of these Eternal Thread locations:

- `https://github.com/GremlinNavi/sovereign-ai-framework(.git)`
- `git@github.com:GremlinNavi/sovereign-ai-framework(.git)`
- `ssh://git@github.com/GremlinNavi/sovereign-ai-framework(.git)`
- `https://gitlab.com/eternal-thread-group/sovereign-ai-framework(.git)`
- `git@gitlab.com:eternal-thread-group/sovereign-ai-framework(.git)`
- `ssh://git@gitlab.com/eternal-thread-group/sovereign-ai-framework(.git)`

Run:

```powershell
.\tools\Update-EternalThread.ps1
```

After checking the worktree, branch, and remote URL, it runs only:

```text
git pull --ff-only origin <current-branch>
```

It never creates commits, pushes, resets, checks out, cleans, stashes, or forces a
Git operation. It also does not resolve a branch divergence for you. Use `-WhatIf`
to preview its gate, and consult `MIRROR_WORKFLOW.md` before treating the GitHub and
GitLab copies as synchronized.

## Trust and verification boundary

The helpers are conveniences, not a sandbox or authenticity-verification system.
`pip install .` builds the source checkout you run, and the update helper invokes
your installed Git executable. Verify a release ZIP against `SHA256SUMS.txt`, scan
it appropriately, and verify any release tag with an independently trusted key
before trusting it. See `RELEASE_AUTHENTICITY.md` and
`ANTIVIRUS_VERIFICATION.md`.

## Optional Windows GUI preferences

The accessibility distribution includes `tools\Set-EternalThreadGuiPreferences.ps1`
for local theme, text scale, and opening-window settings. This helper is Windows
focused; it writes only `gui_preferences.json` in Eternal Thread's local data
directory and does not change source files, `.env`, backend/model settings, Git
configuration, or system-wide accessibility settings.
