# Release provenance — v0.4.0-beta.1

This record separates the retained RC3 input archive, historical RC4 source-candidate
work, and the current beta source-package preparation. It is a local release-
preparation record, not proof that a tag, hosted release, signature, or remote mirror
has been created.

## Declared retained base — owner verification required

- Source archive: `sovereign-ai-demonstrator-eternal-thread-v0.4.0-rc3-nemi-safety-hardened.zip`
- Source SHA-256: `7D23EEF377CA826968953572C73FDD733547E78F61988973DAB0850C9169F141`
- Maintainer/creator identity in project metadata: Nemi Prowse
- Retained-base release line: `v0.4.0-rc3` / Python package version `0.4.0rc3`

The named archive and hash have not been independently verified in this workspace.
The owner must validate them against the retained original. The retained-base hash
does **not** identify a later source ZIP, Git tag, executable, or hosted asset.

## Historical notes — not a final release diff

Earlier RC work removed accidentally packaged local-test material, corrected an
inaccurate exported-helper claim, clarified security-reporting wording, preserved the
release-preparation boundary, and retained Canadian engineering-alignment material.
Those notes are historical context only. They do not describe every difference in this
beta or a later hosted release.

## Current beta source-package scope

`v0.4.0-beta.1` / `0.4.0b1` adds:

- a PowerShell bootstrap that supports Windows PowerShell 5.1 on Windows and
  PowerShell 7+ on Windows, Linux, and macOS;
- a local source ZIP exporter, external ZIP checksum, and in-archive source-tree
  checksum manifest;
- signing, checksum, antivirus, and GitHub/GitLab mirror guidance;
- remote local-inference and embedded-host deployment boundaries; and
- beta-status, licensing, and provenance documentation hardening.

The beta package is intentionally not described as a signed or hosted release. It
does not bundle an inference runtime, model weights, cloud fallback, private data, or
third-party credential.

## Local beta-package record

When `tools/Export-EternalThreadSource.ps1` is run successfully, it creates:

- `eternal-thread-v0.4.0-beta.1-source.zip`;
- a neighbouring `SHA256SUMS.txt`; and
- `SOURCE_TREE_SHA256SUMS.txt` inside the ZIP.

The actual ZIP SHA-256 is recorded in the external `SHA256SUMS.txt` because an
archive cannot safely contain a checksum of its own final bytes. Verify it using
`tools/Test-EternalThreadRelease.ps1`. A local ZIP and checksum do not identify a
Git commit unless the source tree is first committed and the exact tag target is
recorded below.

## Observed mirror state — dated, read-only check

On 2026-09-01, connected read-only checks observed these default-branch heads:

- GitHub `GremlinNavi/sovereign-ai-framework`: `194af2f50be0313469416a4e77da1114ad24115c`
- GitLab `eternal-thread-group/sovereign-ai-framework`: `989b36032c8393a30408e6e11f22a4ec6d385e05`

The values differ, so no synchronization claim is made. Re-check refs immediately
before any release or mirror operation. See [MIRROR_WORKFLOW.md](MIRROR_WORKFLOW.md).

## Final hosted-release provenance — maintainer completion required

Complete this section only after the exact source commit has been reviewed, an
annotated tag has been created, and final assets have been independently verified.

- Canonical public repository URL: `[TO BE COMPLETED]`
- Release tag: `[TO BE COMPLETED; expected beta tag: v0.4.0-beta.1]`
- Tag target commit (full Git object ID): `[TO BE COMPLETED]`
- Tag signing method and trusted key fingerprint: `[TO BE COMPLETED OR NOT USED]`
- Canonical source asset filename and SHA-256: `[TO BE COMPLETED]`
- Checksum-manifest filename and SHA-256: `[TO BE COMPLETED]`
- GitLab mirror/ref and source-tree comparison result: `[TO BE COMPLETED OR NOT PUBLISHED]`
- Antivirus scan record for the final published asset: `[TO BE COMPLETED]`
- Independent post-upload download/checksum verification: `[TO BE COMPLETED]`
- Final diff/review evidence and behavior-impact statement: `[TO BE COMPLETED]`

Do not announce a hosted release until every claim above has been checked against the
actual tag and uploaded assets. Keep this record with the release notes, checksum
manifest, [RELEASE_AUTHENTICITY.md](RELEASE_AUTHENTICITY.md), and the relevant archive
record.

## Licence and component boundary

The source tree is licensed under Apache License 2.0 as stated in `LICENSE` and
`NOTICE`. That licence does not grant rights to third-party model weights, runtimes,
hosted services, datasets, trademarks, signing keys, or user data. The release
workflow must preserve `THIRD_PARTY_NOTICES.md` and `SBOM.cdx.json` alongside the
actual release materials.
