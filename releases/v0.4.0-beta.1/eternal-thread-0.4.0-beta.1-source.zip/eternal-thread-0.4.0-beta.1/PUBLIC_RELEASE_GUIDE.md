# Public source-beta release guide

This is the practical path from the locally prepared beta source tree to a deliberate
public pre-release. It does not replace legal advice, platform documentation, key
management, or a maintainer's review of the exact repository and assets being
published.

## 1. Decide what may be public

Before making code, documentation, releases, or a repository public, confirm the
public authorship, contributor authority, project-name wording, patent/disclosure
decision, and any content that must remain confidential. Review full Git history,
all refs, tags, assets, forks, and CI logs—not only the current worktree.

Keep local data out of the source set: conversation history, audit logs, knowledge
files and indexes, .env files, API keys, private certificates, local paths, and
training/review data must not be released. From the actual Git checkout, run:

```powershell
.\tools\Test-PublicReleaseReadiness.ps1 -Version v0.4.0-beta.1 -RequireClean
```

The audit is read-only and cannot prove the absence of private data. Complete every
applicable item in RELEASE_CHECKLIST.md before publication.

## 2. Build the source package locally

From the reviewed source checkout, first preview the export:

```powershell
pwsh -File .\tools\Export-EternalThreadSource.ps1 `
  -Version v0.4.0-beta.1 `
  -OutputDirectory C:\releases `
  -WhatIf
```

After inspecting the file count and output location, run the same command without
-WhatIf. The exporter refuses to overwrite a release ZIP or SHA256SUMS.txt, does
not create a Git tag, and does not contact a forge. It writes an in-archive
SOURCE_TREE_SHA256SUMS.txt plus a neighbouring ZIP checksum manifest.

Verify the output before upload:

```powershell
pwsh -File .\tools\Test-EternalThreadRelease.ps1 `
  -ChecksumFile C:\releases\SHA256SUMS.txt `
  -ReleaseAsset C:\releases\eternal-thread-v0.4.0-beta.1-source.zip `
  -RequireSourceTreeManifest
```

See RELEASE_AUTHENTICITY.md and ANTIVIRUS_VERIFICATION.md for the separate integrity,
signing, and scanner layers.

## 3. Preserve the local-first boundary

A Python virtual environment isolates this project's Python dependencies and adapter
libraries. It does not install or start an inference runtime, download model weights,
or choose a model. The project does not automatically discover a server or fail over
to a cloud provider. A non-loopback endpoint requires the explicit remote-backend
opt-in and in-application consent.

The source beta contains Python adapters, not an inference runtime or model
distribution. Operators separately choose a compatible local runtime, its model
weights, endpoint security, and licence terms. See REMOTE_LOCAL_INFERENCE.md for the
remote-LAN and embedded-endpoint boundary.

## 4. Tag and mirror deliberately

Only after the final source has been reviewed, create an annotated beta tag. If a
maintainer signing key is configured, sign and independently verify it. Record the
exact tag target and signing status in PROVENANCE.md.

The currently configured GitHub and GitLab default branches were observed to differ
during beta preparation. Re-check the intended refs, choose the canonical host for
this particular release, and mirror without force-pushing history. See
MIRROR_WORKFLOW.md for the required comparison and GitHub-CLI preflight boundary.

## 5. Publish and independently verify

Publish the beta only as a pre-release, attach the exact ZIP, SHA256SUMS.txt, and
release notes, then independently download each asset and compare its hash. Complete
the final-public-release fields in PROVENANCE.md and the versioned record in
docs/archive/ with the actual URLs, tag, tag target, asset names, checksum values,
signing status, and verification evidence.

Do not announce the beta as signed, mirror-synchronized, antivirus-certified,
production-ready, or universally portable unless the corresponding verified evidence
exists for the exact published artifacts.
