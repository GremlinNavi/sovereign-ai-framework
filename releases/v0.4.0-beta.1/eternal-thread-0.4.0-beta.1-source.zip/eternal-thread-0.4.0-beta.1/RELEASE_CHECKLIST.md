# Source-beta release checklist — v0.4.0-beta.1

`[x]` records a fact present in this local source-preparation tree. It is not a
confirmation that a remote repository, account setting, signed tag, release asset,
or legal decision is complete. `[ ]` is a maintainer gate for the exact source and
assets that will be published.

## Source-preparation facts

- [x] Apache-2.0 `LICENSE`, `NOTICE`, `IP_POLICY.md`, `TRADEMARKS.md`, `DCO.md`,
  `AUTHORS.md`, and `CITATION.cff` are present.
- [x] Package and citation metadata identify this build as experimental beta
  `v0.4.0-beta.1`, not stable `v0.4.0`.
- [x] `THIRD_PARTY_NOTICES.md` and `SBOM.cdx.json` are present.
- [x] The project documents separate Python dependency, inference-runtime, model,
  remote-endpoint, privacy, and consent boundaries with no automatic cloud fallback.
- [x] `Install-EternalThread.ps1` supports Windows PowerShell 5.1 on Windows and
  PowerShell 7+ on Windows, Linux, and macOS without changing execution policy,
  installing a runtime/model, overwriting `.env`, or performing Git operations.
- [x] Local-only source-package and checksum-verification helpers are present.
- [x] Signing, antivirus, GitHub/GitLab mirror, and remote-local-inference guidance
  clearly records its limits rather than claiming completed outside-world actions.
- [x] Pull-request CI checks DCO `Signed-off-by:` trailers on proposed commits.

## Maintainer gates before a public beta

- [ ] Review every tracked file and release archive for personal data, local paths,
  credentials, private keys, certificates, and material lacking release permission.
- [ ] Review the complete Git history, branches, tags, releases, forks, and CI logs;
  `.gitignore` does not remove sensitive material from historical commits.
- [ ] If history cannot safely become public, create a separately reviewed public
  source history. Do not change repository visibility merely because one tree is
  clean.
- [ ] Confirm the public authorship, copyright, contribution authority, project name,
  and trademark wording the creator wants permanently associated with the project.
- [ ] Confirm the security-reporting path and host protections are accurate for the
  intended public repository.
- [ ] Review each PowerShell helper from the exact release commit and smoke-test the
  claimed platform paths in appropriate clean environments.
- [ ] Regenerate `THIRD_PARTY_NOTICES.md` and `SBOM.cdx.json` from a clean,
  version-pinned environment if dependencies or package metadata changed.
- [ ] Do not upload private or unreleased material to a public cloud malware scanner.

## Verification gate — exact final source

```text
python -m venv .venv
# activate the environment for the current platform
pip install -r requirements-test.lock
python -m compileall -q app tests config.py launcher.py
python config.py --validate
pytest -q
```

- [ ] The full test suite passes in the reviewed locked environment.
- [ ] Any intended Windows executable is built and smoke-tested separately on a
  clean supported Windows environment.
- [ ] The final source ZIP is created from the exact reviewed commit, not an
  untracked staging folder.
- [ ] The ZIP is scanned before upload and after an independent download.
- [ ] `SHA256SUMS.txt` is created for every final asset and verified independently.
- [ ] Run the read-only source-package verifier, for example:

  ```powershell
  pwsh -File .\tools\Test-EternalThreadRelease.ps1 `
    -ChecksumFile C:\releases\SHA256SUMS.txt `
    -ReleaseAsset C:\releases\eternal-thread-v0.4.0-beta.1-source.zip `
    -RequireSourceTreeManifest
  ```

- [ ] Run `tools/Test-PublicReleaseReadiness.ps1 -Version v0.4.0-beta.1
  -RequireClean` from inside the actual Git repository. Treat warnings as human
  review work; the audit is not proof that private material is absent.

## Provenance and signing gate

- [ ] Review the final diff and record the actual behavior-impact statement.
- [ ] Create an annotated `v0.4.0-beta.1` tag only after the source gates pass.
- [ ] If signing is configured, verify the tag with the expected trusted GPG or SSH
  key and record the signing method/fingerprint. If no signature is used, say so.
- [ ] Record the exact tag target, asset names, SHA-256 values, scan evidence, and
  independent-download verification in `PROVENANCE.md` and `docs/archive/`.
- [ ] Do not reuse a retained-input or prior-release hash as a beta-asset hash.

## GitHub/GitLab and publication gate

- [ ] Re-check the chosen canonical host and mirror refs. The two observed default
  branches were divergent during beta preparation.
- [ ] Push only through an approved reviewed workflow; do not force-push or rewrite
  one host merely to make histories look identical.
- [ ] Mark any GitHub beta release as a **pre-release** and state its experimental
  status and known limitations.
- [ ] Attach the exact source ZIP, `SHA256SUMS.txt`, release notes, and any approved
  companion assets.
- [ ] Verify every uploaded asset against the published checksum after download.
- [ ] Publish a mirror/reference only after recording what it represents and whether
  it is public or private.

## Claims boundary

- [ ] Use the title: “Eternal Thread - Sovereign AI Demonstrator.”
- [ ] Use accurate capability language: “local-first,” “auditable,” and
  “human-controlled,” with the documented feature boundaries.
- [ ] Do not imply Government of Canada ownership, endorsement, procurement,
  certification, legal compliance, production readiness, or universal hardware
  support.
- [ ] Reserve stable `v0.4.0` until the appropriate release, test, security, and
  provenance gates are complete.
