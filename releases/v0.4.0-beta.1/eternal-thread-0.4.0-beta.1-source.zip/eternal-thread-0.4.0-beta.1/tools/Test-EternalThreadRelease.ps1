# SPDX-FileCopyrightText: 2026 Nemi Prowse
# SPDX-License-Identifier: Apache-2.0
<#
.SYNOPSIS
Verifies one or more Eternal Thread release assets against SHA256SUMS.txt.

.DESCRIPTION
This read-only helper compares each named asset with the matching SHA-256 manifest
entry. It does not extract an archive, run project code, contact a network service,
modify Git, or change any file.

.EXAMPLE
.\tools\Test-EternalThreadRelease.ps1 -ChecksumFile .\SHA256SUMS.txt `
  -ReleaseAsset .\eternal-thread-v0.4.0-beta.1-source.zip
#>
[CmdletBinding()]
param(
    [ValidateNotNullOrEmpty()]
    [string]$ChecksumFile = (Join-Path (Get-Location).Path 'SHA256SUMS.txt'),

    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string[]]$ReleaseAsset,

    [switch]$RequireSourceTreeManifest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-ExpectedHash {
    param(
        [Parameter(Mandatory)][string]$ManifestPath,
        [Parameter(Mandatory)][string]$AssetName
    )

    foreach ($line in Get-Content -LiteralPath $ManifestPath) {
        if ($line -match '^\s*([A-Fa-f0-9]{64})\s+\*?(.+?)\s*$' -and $Matches[2] -eq $AssetName) {
            return $Matches[1].ToUpperInvariant()
        }
    }
    return $null
}

function Test-SourceTreeManifest {
    param([Parameter(Mandatory)][string]$ArchivePath)

    Add-Type -AssemblyName System.IO.Compression
    $stream = [IO.File]::Open($ArchivePath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Read, $false)
    try {
        return $null -ne ($archive.Entries | Where-Object { $_.FullName -match '(^|/)SOURCE_TREE_SHA256SUMS\.txt$' } | Select-Object -First 1)
    } finally {
        $archive.Dispose()
        $stream.Dispose()
    }
}

try {
    if (-not (Test-Path -LiteralPath $ChecksumFile -PathType Leaf)) {
        throw "Checksum manifest was not found: $ChecksumFile"
    }

    foreach ($asset in $ReleaseAsset) {
        if (-not (Test-Path -LiteralPath $asset -PathType Leaf)) {
            throw "Release asset was not found: $asset"
        }
        $assetName = [IO.Path]::GetFileName($asset)
        $expectedHash = Get-ExpectedHash -ManifestPath $ChecksumFile -AssetName $assetName
        if (-not $expectedHash) {
            throw "Checksum manifest has no entry for release asset: $assetName"
        }
        $actualHash = (Get-FileHash -LiteralPath $asset -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedHash) {
            throw "SHA-256 mismatch for release asset: $assetName"
        }
        if ($RequireSourceTreeManifest -and [IO.Path]::GetExtension($asset).Equals('.zip', [StringComparison]::OrdinalIgnoreCase)) {
            if (-not (Test-SourceTreeManifest -ArchivePath $asset)) {
                throw "Release ZIP does not contain SOURCE_TREE_SHA256SUMS.txt: $assetName"
            }
        }
        Write-Output "SHA-256 verified: $assetName"
    }
    Write-Output 'All named release assets matched the checksum manifest. No file, Git, or network change was made.'
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
