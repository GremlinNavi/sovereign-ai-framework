# SPDX-FileCopyrightText: 2026 Nemi Prowse
# SPDX-License-Identifier: Apache-2.0
<#
.SYNOPSIS
Creates a source-only Eternal Thread ZIP and a companion SHA-256 checksum manifest.

.DESCRIPTION
This Windows PowerShell 5.1+ and PowerShell 7+ helper packages the reviewed source
tree without reading or modifying Git, contacting a network service, creating tags,
or replacing existing release files. It excludes local configuration, virtual
environments, private application data, build products, secrets, caches, and
reparse points. The ZIP contains SOURCE_TREE_SHA256SUMS.txt for file-level review;
the adjacent SHA256SUMS.txt verifies the ZIP itself.

.PARAMETER Version
Version used in the output ZIP name. It does not create a Git tag or a hosted release.

.PARAMETER OutputDirectory
Directory outside the source tree that will receive the ZIP and SHA256SUMS.txt.
The default is a sibling directory named eternal-thread-release-output.

.EXAMPLE
.\tools\Export-EternalThreadSource.ps1 -Version v0.4.0-beta.1

.EXAMPLE
.\tools\Export-EternalThreadSource.ps1 -OutputDirectory C:\releases -WhatIf
#>
[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
param(
    [ValidatePattern('^v?\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$')]
    [string]$Version = 'v0.4.0-beta.1',

    [ValidateNotNullOrEmpty()]
    [string]$OutputDirectory = (Join-Path $PSScriptRoot '..\..\eternal-thread-release-output')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:IsWindowsPlatform = $env:OS -eq 'Windows_NT'
if ($PSVersionTable.PSEdition -eq 'Core') {
    $script:IsWindowsPlatform = [bool]$IsWindows
}
$script:PathComparison = if ($script:IsWindowsPlatform) {
    [StringComparison]::OrdinalIgnoreCase
} else {
    [StringComparison]::Ordinal
}

$excludedDirectoryNames = @(
    '.git', '.venv', 'venv', '__pycache__', '.pytest_cache', '.ip-build-env',
    '.professionalism-audit-data', '.professionalism-audit-pytest', 'build', 'dist'
)

function Test-PathWithinRoot {
    param(
        [Parameter(Mandatory)][string]$Candidate,
        [Parameter(Mandatory)][string]$Root
    )

    $rootWithSeparator = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    return $Candidate.Equals($Root, $script:PathComparison) -or $Candidate.StartsWith($rootWithSeparator, $script:PathComparison)
}

function Get-ReleaseRelativePath {
    param(
        [Parameter(Mandatory)][string]$FullPath,
        [Parameter(Mandatory)][string]$RepositoryRoot
    )

    if (-not (Test-PathWithinRoot -Candidate $FullPath -Root $RepositoryRoot)) {
        throw "Refusing to package a path outside the source tree: $FullPath"
    }
    return $FullPath.Substring($RepositoryRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar).Replace('\', '/')
}

function Test-ExcludedDirectory {
    param([Parameter(Mandatory)][string]$RelativePath)

    foreach ($segment in ($RelativePath -split '/')) {
        if ($excludedDirectoryNames -contains $segment -or $segment -like '*.egg-info' -or $segment -like 'pytest-of-*') {
            return $true
        }
    }
    return $false
}

function Test-IncludedReleaseFile {
    param([Parameter(Mandatory)][string]$RelativePath)

    $normalised = $RelativePath.Replace('\', '/')
    if ($normalised -eq '.env' -or ($normalised -like '.env.*' -and $normalised -ne '.env.example')) { return $false }
    if ($normalised -match '(^|/)(privacy_consent|gui_preferences)\.json$') { return $false }
    if ($normalised -match '(^|/)(id_rsa|id_dsa|id_ecdsa|id_ed25519)(\.pub)?$') { return $false }
    if ($normalised -match '(^|/)(credentials\.json|secrets\.[^/]+)$') { return $false }
    if ($normalised -match '\.(pem|key|pfx|p12|kdbx|sqlite3|sqlite3-shm|sqlite3-wal|spec)$') { return $false }
    if ($normalised -match '^conversation_history/(tool_audit\.jsonl|safety_events\.jsonl)$') { return $false }
    if ($normalised -match '^conversation_history/sessions/(?!\.gitkeep$)') { return $false }
    if ($normalised -match '^knowledge/(?!\.gitkeep$)') { return $false }
    if ($normalised -match '^training_data/(raw|review|curated)/(?!\.gitkeep$)') { return $false }
    return $true
}

function Get-ReleaseFiles {
    param([Parameter(Mandatory)][string]$RepositoryRoot)

    $pending = [Collections.Generic.Stack[string]]::new()
    $pending.Push($RepositoryRoot)
    $files = [Collections.Generic.List[IO.FileInfo]]::new()

    while ($pending.Count -gt 0) {
        $currentPath = $pending.Pop()
        foreach ($item in (Get-ChildItem -LiteralPath $currentPath -Force | Sort-Object -Property Name)) {
            $relativePath = Get-ReleaseRelativePath -FullPath $item.FullName -RepositoryRoot $RepositoryRoot
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "Refusing to package a symbolic link or junction: $relativePath"
            }
            if ($item.PSIsContainer) {
                if (-not (Test-ExcludedDirectory -RelativePath $relativePath)) {
                    $pending.Push($item.FullName)
                }
            } elseif (Test-IncludedReleaseFile -RelativePath $relativePath) {
                $files.Add($item)
            }
        }
    }

    return @($files | Sort-Object -Property FullName)
}

try {
    $repositoryRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $outputFullPath = [IO.Path]::GetFullPath($OutputDirectory)
    if (Test-PathWithinRoot -Candidate $outputFullPath -Root $repositoryRoot) {
        throw 'OutputDirectory must be outside the source tree so a release cannot package itself.'
    }

    $normalizedVersion = if ($Version.StartsWith('v')) { $Version } else { "v$Version" }
    $archiveName = "eternal-thread-$($normalizedVersion.TrimStart('v'))-source.zip"
    $archivePath = Join-Path $outputFullPath $archiveName
    $checksumPath = Join-Path $outputFullPath 'SHA256SUMS.txt'
    $topLevelDirectory = "eternal-thread-$($normalizedVersion.TrimStart('v'))"
    $releaseFiles = Get-ReleaseFiles -RepositoryRoot $repositoryRoot

    if ($releaseFiles.Count -eq 0) {
        throw 'No source files were selected for the release archive.'
    }
    if (Test-Path -LiteralPath $archivePath -PathType Leaf) {
        throw "Refusing to replace existing release ZIP: $archivePath"
    }
    if (Test-Path -LiteralPath $checksumPath -PathType Leaf) {
        throw "Refusing to replace existing checksum manifest: $checksumPath"
    }

    Write-Output 'Eternal Thread source-package exporter'
    Write-Output "Source tree: $repositoryRoot"
    Write-Output "Version: $normalizedVersion"
    Write-Output "Files selected: $($releaseFiles.Count)"
    Write-Output "Output ZIP: $archivePath"

    if (-not $PSCmdlet.ShouldProcess($outputFullPath, 'create a source ZIP and SHA-256 checksum manifest')) {
        Write-Output 'Package preview complete; no archive, checksum manifest, Git, or remote change was made.'
        return
    }

    [IO.Directory]::CreateDirectory($outputFullPath) | Out-Null
    Add-Type -AssemblyName System.IO.Compression
    $stream = $null
    $archive = $null
    $failure = $null
    $manifestLines = [Collections.Generic.List[string]]::new()
    $utf8NoBom = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false

    try {
        $stream = [IO.File]::Open($archivePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $false)
        foreach ($file in $releaseFiles) {
            $relativePath = Get-ReleaseRelativePath -FullPath $file.FullName -RepositoryRoot $repositoryRoot
            $entry = $archive.CreateEntry("$topLevelDirectory/$relativePath", [IO.Compression.CompressionLevel]::Optimal)
            $entry.LastWriteTime = [DateTimeOffset]::new($file.LastWriteTimeUtc)
            $input = $null
            $output = $null
            try {
                $input = [IO.File]::OpenRead($file.FullName)
                $output = $entry.Open()
                $input.CopyTo($output)
            } finally {
                if ($null -ne $output) { $output.Dispose() }
                if ($null -ne $input) { $input.Dispose() }
            }
            $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToUpperInvariant()
            $manifestLines.Add("$hash *$relativePath")
        }

        $manifestEntry = $archive.CreateEntry("$topLevelDirectory/SOURCE_TREE_SHA256SUMS.txt", [IO.Compression.CompressionLevel]::Optimal)
        $manifestEntry.LastWriteTime = [DateTimeOffset]::UtcNow
        $writer = $null
        try {
            $writer = New-Object -TypeName System.IO.StreamWriter -ArgumentList @($manifestEntry.Open(), $utf8NoBom)
            $writer.WriteLine('# SHA-256 values for source files in this archive; the adjacent SHA256SUMS.txt verifies the ZIP itself.')
            foreach ($line in $manifestLines) { $writer.WriteLine($line) }
        } finally {
            if ($null -ne $writer) { $writer.Dispose() }
        }
    } catch {
        $failure = $_
    } finally {
        if ($null -ne $archive) { $archive.Dispose() }
        if ($null -ne $stream) { $stream.Dispose() }
    }

    if ($null -ne $failure) {
        if (Test-Path -LiteralPath $archivePath -PathType Leaf) {
            [IO.File]::Delete($archivePath)
        }
        throw $failure
    }

    $archiveHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToUpperInvariant()
    [IO.File]::WriteAllText($checksumPath, "$archiveHash *$archiveName`n", $utf8NoBom)
    Write-Output "Created source ZIP: $archivePath"
    Write-Output "Created checksum manifest: $checksumPath"
    Write-Output "SHA-256: $archiveHash"
    Write-Output 'No Git, tag, remote, runtime, model, or configuration change was made.'
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
