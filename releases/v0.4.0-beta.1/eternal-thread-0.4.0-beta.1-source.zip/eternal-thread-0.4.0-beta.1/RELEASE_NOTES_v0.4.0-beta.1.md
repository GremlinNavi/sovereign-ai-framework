# v0.4.0-beta.1 — Beta #1

Eternal Thread v0.4.0-beta.1 is an experimental source beta for local review. It is
not a stable or production release and is not a Government of Canada product,
service, endorsement, procurement, certification, or deployment.

## Highlights

- Extends the opt-in installer to Windows PowerShell 5.1 on Windows and PowerShell
  7+ on Windows, Linux, and macOS. It uses the platform-correct virtual-environment
  Python path and still refuses to change execution policy, overwrite `.env`,
  install a runtime/model, or perform Git operations.
- Adds an inspectable source-package exporter and a checksum verifier for a portable
  ZIP release workflow. The exporter writes a ZIP, adjacent `SHA256SUMS.txt`, and an
  in-archive source-tree manifest without changing a repository or remote.
- Adds signed-tag, checksum, and antivirus-verification guidance that distinguishes
  integrity checks, signing evidence, and scanner results.
- Adds a GitHub/GitLab mirror workflow that records the observed divergent branch
  state rather than overstating synchronization.
- Documents explicit remote local-inference and embedded-endpoint designs, including
  the consent, network, authentication, and physical-safety boundaries.
- Hardens provenance and licensing documentation around the beta status, source
  package, third-party boundaries, and future hosted-release record.

## Deliberate boundaries and known limitations

- This package does not contain an actual signed Git tag, signing key, hosted GitHub
  Release, GitLab Release, or remote update.
- The GitHub and GitLab default branches observed during preparation differed; do not
  assume they are mirrors until a maintainer verifies the intended release refs.
- No inference runtime, model weights, cloud fallback, embedded firmware, or
  universal-device support is bundled or claimed.
- The beta source archive must still be reviewed, scanned, and verified with its
  adjacent checksum before use.

Before any hosted pre-release, complete `RELEASE_CHECKLIST.md`, create and verify a
signed tag if a maintainer key is available, record exact release references in
`PROVENANCE.md`, and verify every uploaded asset independently.
