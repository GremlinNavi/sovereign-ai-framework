# Remote local-inference and embedded-host guidance

Eternal Thread can use an explicitly configured inference endpoint that is not on
the same loopback interface as the application. This supports a local-network design
where a lightweight device provides interaction while a separately managed machine
performs inference. It does not turn the framework into an automatic device-
discovery, authentication, TLS, firewall, fleet-management, or embedded-firmware
system.

## Supported configuration boundary

The current adapters are `ollama` and `openai_compatible`. Chat and embedding
backends may be selected independently in `config.py` or `.env`. A non-loopback
endpoint is rejected unless the operator explicitly sets:

```text
ETERNAL_THREAD_ALLOW_REMOTE_BACKENDS=1
```

The application also requires explicit in-application consent before a remote
backend can be used. It never auto-discovers a server, installs a runtime or model,
downloads model weights, or falls back to a cloud endpoint when a local endpoint is
unavailable.

The endpoint may still be physically local to the operator—for example, another
machine on a private LAN. In the code, however, anything other than `localhost`,
`127.0.0.1`, or `::1` is intentionally treated as remote because it crosses a
network boundary and needs extra data-transfer review.

## Reference topologies

```text
Single-machine development
  desktop application -> 127.0.0.1 inference runtime

Private-LAN host
  desktop / handheld UI -> private LAN -> authenticated inference host

Embedded endpoint
  microphone, speaker, buttons, or display
        -> Raspberry Pi-class endpoint
        -> private LAN
        -> separately managed inference host
        -> configured local model/runtime
```

The embedded endpoint can remain a user-interface and I/O device rather than trying
to run a large model itself. The inference host can be a desktop, mini-PC, handheld,
or other supported machine. Replacing the endpoint, model, or runtime should not
require a change to the research, records, RAG, and export abstractions.

## Secure deployment checklist

- Keep the inference service on a private network; do not expose an unauthenticated
  model port to the public internet.
- Use authenticated transport and encryption appropriate to the network design,
  such as a properly configured TLS reverse proxy or private secure overlay. The
  application does not create those controls for you.
- Store API credentials only in environment variables or an operator-managed secret
  store. Do not commit them to `.env`, the source archive, a device image, or a
  conversation export.
- Segment untrusted client devices from the inference host where practical, and
  restrict the host firewall to the known clients and ports.
- Choose a fixed or discoverable private address under the operator's own network
  policy; re-run the health check after an address, runtime, model, or certificate
  change.
- Treat microphones, cameras, batteries, chargers, heat, and physical enclosures as
  separate privacy and product-safety concerns. A toy or other soft enclosure is not
  a safe production hardware design without specialist review.

## Validate before use

After deliberately configuring the endpoint, run:

```text
python config.py --validate
python config.py --health-check
```

The health check contacts only the configured chat and embedding endpoints and checks
that their configured models are listed. It does not prove support for every declared
capability or select an alternative backend. Rebuild the local retrieval index when
the embedding backend or embedding model changes.

This beta documents a design boundary and an operator workflow. It does not claim universal
Raspberry Pi, Android, Steam Deck, CFW handheld, Arcade1Up, or other embedded-device
support, nor does it claim that any third-party runtime is private, secure, compatible,
or licensed for every deployment.
