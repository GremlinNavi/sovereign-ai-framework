# Antivirus and malware-verification guidance

Antivirus scanning is a useful release gate, but it is neither a substitute for
cryptographic verification nor proof that a file is safe. Treat it as one layer in a
release process that also includes source review, checksum verification, a signed tag
when available, and a trusted download path.

## Safe verification sequence

1. Obtain the ZIP and `SHA256SUMS.txt` from the documented release location.
2. Verify the ZIP's SHA-256 value before opening it.
3. Scan the ZIP itself with an up-to-date endpoint-security product.
4. Extract it to a fresh folder and scan the extracted files as well.
5. Review the top-level licence, provenance, and release-note documents before
   running a script or installing Python dependencies.
6. Run the optional PowerShell helper with `-WhatIf` first, then inspect the source
   you intend to execute.

For Windows Defender on a personally administered machine, a user may run a targeted
scan from an elevated PowerShell session if their policy permits it:

```powershell
Start-MpScan -ScanType CustomScan -ScanPath C:\path\to\eternal-thread-v0.4.0-beta.1-source.zip
Start-MpScan -ScanType CustomScan -ScanPath C:\path\to\extracted-eternal-thread
```

On Linux, an operator who has deliberately installed ClamAV may use a recursive
`clamscan` scan of the ZIP and extracted directory. On macOS, use the organization's
approved endpoint-protection product; Gatekeeper assessment and notarization apply to
specific app-distribution scenarios and do not authenticate this source archive.

## Privacy warning for cloud scanners

Do not upload unreleased, private, customer, confidential, or personally identifying
source material to a public multi-engine scanning service. Such services may retain,
share, or make sample data available to other researchers or customers. A local
scanner, private enterprise sandbox, or approved security-review process is safer for
non-public artifacts.

If a public release asset is submitted to a third-party scanner, record the exact
file hash, scan date, scanner name, and result in a release review record. Do not
claim that a third-party scan certifies the project or its hosted release.

## Handling detections

Treat a detection as a release stop, not as a reason to suppress a scanner warning.
Preserve the exact file hash and scanner result, reproduce the scan in an isolated
environment if appropriate, inspect the source/build inputs, and either remediate or
document a verified false positive through the security reporting process. Do not
redistribute a changed asset under the old checksum.

See [RELEASE_AUTHENTICITY.md](RELEASE_AUTHENTICITY.md) for the checksum and signed-
tag workflow. The current beta includes source and helper scripts; it does not bundle
an inference runtime, model weights, or a claim of malware certification.
